// Copyright (C) 2011  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_DISJOINt_SUBSETS_
#define DLIB_DISJOINt_SUBSETS_


#include "disjoint_subsets/disjoint_subsets.h"
#include "disjoint_subsets/disjoint_subsets_sized.h"

#endif // DLIB_DISJOINt_SUBSETS_


